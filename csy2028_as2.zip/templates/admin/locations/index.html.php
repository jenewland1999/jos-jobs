<main class="sidebar">
    <?php include __DIR__ . '/../navigation.html.php'; ?>
    <section class="right">
        <h2>Locations</h2>

        <a class="new" href="/admin/locations/create">
            Create new location
        </a>

        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th style="width: 5%;">&nbsp;</th>
                    <th style="width: 5%;">&nbsp;</th>
                </tr>
                <?php foreach($locations as $location): ?>
                    <tr>
                        <td>
                            <?php echo htmlspecialchars($location['name'], ENT_QUOTES, 'UTF-8'); ?>
                        </td>
                        <td>
                            <a style="float: right;" href="/admin/locations/update?id=<?php echo $location['location_id']; ?>">
                                Update
                            </a>
                        </td>
                        <td>
                            <form action="/admin/locations/delete" method="post">
                                <input type="hidden" name="id" value="<?php echo $location['location_id']; ?>" />
                                <input type="submit" name="submit" value="Delete" />
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </thead>
        </table>
    </section>
</main>
