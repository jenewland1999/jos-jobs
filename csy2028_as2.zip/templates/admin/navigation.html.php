<aside class="sidebar-navigation left">
    <ul class="sidebar-navigation__nav">
        <li class="sidebar-navigation__nav-item">
            <a href="/admin/categories" class="sidebar-navigation__nav-link">
                Categories
            </a>
        </li>
        <li class="sidebar-navigation__nav-item">
            <a href="/admin/locations" class="sidebar-navigation__nav-link">
                Locations
            </a>
        </li>
        <li class="sidebar-navigation__nav-item">
            <a href="/admin/jobs" class="sidebar-navigation__nav-link">
                Jobs
            </a>
        </li>
        <li class="sidebar-navigation__nav-item">
            <a href="/admin/users" class="sidebar-navigation__nav-link">
                Users
            </a>
        </li>
    </ul>
</aside>
