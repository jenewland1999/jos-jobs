<main class="sidebar">
    <?php include __DIR__ . '/../navigation.html.php'; ?>
    <section class="right">
        <h2><?php echo isset($_GET['id']) ? 'Update' : 'Create' ?> User</h2>

        <form action="" method="POST">
            <label for="user_email">Email Address</label>
            <input
                type="email"
                name="user[email]"
                id="user_email"
                value="<?php echo htmlspecialchars($user['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
            />

            <label for="user_pwd">Password</label>
            <input
                type="password"
                name="user[password]"
                id="user_pwd"
            />
            <small>Passwords cannot be edited. Please set a new password.</small>

            <input type="hidden" name="user[user_id]" value="<?php echo $user['user_id'] ?? ''; ?>" />
            <input type="submit" name="submit" value="<?php echo isset($_GET['id']) ? 'Update' : 'Create' ?>" />
        </form>
    </section>
</main>
