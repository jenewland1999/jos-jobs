<main class="sidebar">
    <?php include __DIR__ . '/../navigation.html.php'; ?>
    <section class="right">
        <h2>Admin/Client Users</h2>

        <a class="new" href="/admin/users/create">
            Create new user
        </a>

        <table>
            <thead>
                <tr>
                    <th>Email</th>
                    <th style="width: 10%;">Access Level</th>
                    <th style="width: 5%;">&nbsp;</th>
                    <th style="width: 5%;">&nbsp;</th>
                </tr>
                <?php foreach($users as $user): ?>
                    <tr>
                        <td>
                            <?php echo htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?>
                        </td>
                        <td>
                            <?php echo htmlspecialchars($user['perm_lvl'], ENT_QUOTES, 'UTF-8'); ?>
                        </td>
                        <td>
                            <a style="float: right;" href="/admin/users/update?id=<?php echo $user['user_id']; ?>">
                                Update
                            </a>
                        </td>
                        <td>
                            <form action="/admin/users/delete" method="post">
                                <input type="hidden" name="id" value="<?php echo $user['user_id']; ?>" />
                                <input type="submit" name="submit" value="Delete" />
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </thead>
        </table>
    </section>
</main>
