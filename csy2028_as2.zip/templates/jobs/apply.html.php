<main class="home">
    <h2>
        Apply for
        <?php echo $job['title']; ?>
    </h2>

    <form action="" method="post" enctype="multipart/form-data">
        <label>Your name</label>
        <input type="text" name="application[name]" />

        <label>E-mail address</label>
        <input type="text" name="application[email]" />

        <label>Cover letter</label>
        <textarea name="application[details]"></textarea>

        <label>CV</label>
        <input type="file" name="cv" />

        <input type="hidden" name="application[job_id]" value="<?php echo $job['job_id'];?>" />

        <input type="submit" name="submit" value="Apply" />
    </form>
</main>
