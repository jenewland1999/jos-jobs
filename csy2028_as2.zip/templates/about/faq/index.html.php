<main class="home">
    <h2>Frequently Asked Questions</h2>
    <p>FAQs comming soon...</p>
</main>
