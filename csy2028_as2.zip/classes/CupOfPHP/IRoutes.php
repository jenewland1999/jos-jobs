<?php

namespace CupOfPHP;

interface IRoutes
{
    public function getRoutes();
}
