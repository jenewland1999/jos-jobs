<?php

namespace JosJobs\Controllers;

use CupOfPHP\DatabaseTable;

class User
{
    private $usersTable;

    public function __construct(DatabaseTable $usersTable)
    {
        $this->usersTable = $usersTable;
    }

    public function read()
    {
        $users = $this->usersTable->findAll();

        return [
            'template' => '/admin/users/index.html.php',
            'title' => 'Admin - Users',
            'variables' => [
                'users' => $users
            ]
        ];
    }

    public function update()
    {
        if (isset($_GET['id'])) {
            $user = $this->usersTable->find('user_id', $_GET['id'])[0];
            $title = 'Admin - Users - Update';
        } else {
            $title = 'Admin - Users - Create';
        }

        return [
            'template' => '/admin/users/update.html.php',
            'title' => $title,
            'variables' => [
                'user' => $user ?? null
            ]
        ];
    }

    public function saveUpdate()
    {
        $_POST['user']['password'] = password_hash($_POST['user']['password'], PASSWORD_DEFAULT);
        $this->usersTable->save($_POST['user']);

        header('location: /admin/users/');
    }

    public function delete()
    {
        $this->usersTable->delete('user_id', $_POST['id']);

        header('location: /admin/users/');
    }
}
