<?php

namespace JosJobs\Controllers;

use CupOfPHP\DatabaseTable;

class Category
{
    private $categoriesTable;

    public function __construct(
        DatabaseTable $categoriesTable
    ) {
        $this->categoriesTable = $categoriesTable;
    }

    public function read()
    {
        $categories = $this->categoriesTable->findAll();

        return [
            'template' => '/admin/categories/index.html.php',
            'title' => 'Admin - Categories',
            'variables' => [
                'categories' => $categories
            ]
        ];
    }

    public function update()
    {
        if (isset($_GET['id'])) {
            $category = $this->categoriesTable->find('category_id', $_GET['id'])[0];
            $title = 'Admin - Categories - Update';
        } else {
            $title = 'Admin - Categories - Create';
        }

        return [
            'template' => '/admin/categories/update.html.php',
            'title' => $title,
            'variables' => [
                'category' => $category ?? null
            ]
        ];
    }

    public function saveUpdate()
    {
        $this->categoriesTable->save($_POST['category']);

        header('location: /admin/categories/');
    }

    public function delete()
    {
        $this->categoriesTable->delete('category_id', $_POST['id']);

        header('location: /admin/categories/');
    }
}
