<?php

namespace JosJobs\Controllers;

use CupOfPHP\DatabaseTable;

class Job
{
    private $applicationsTable;
    private $categoriesTable;
    private $jobsTable;

    public function __construct(
        DatabaseTable $applicationsTable,
        DatabaseTable $categoriesTable,
        DatabaseTable $jobsTable,
        DatabaseTable $locationsTable
    ) {
        $this->applicationsTable = $applicationsTable;
        $this->categoriesTable = $categoriesTable;
        $this->jobsTable = $jobsTable;
        $this->locationsTable = $locationsTable;
    }

    public function read()
    {
        // Fetch a list of categories
        $categories = $this->categoriesTable->findAll();

        // Fetch a list of locations
        $locations = $this->locationsTable->findAll();

        if (isset($_GET['category']) && isset($_GET['location'])) {
            $heading = sprintf(
                '%s Jobs in %s',
                $this->categoriesTable->find('category_id', $_GET['category'])[0]['name'],
                $this->locationsTable->find('location_id', $_GET['location'])[0]['name']
            );
            $jobs = $this->jobsTable->findComplex(
                [
                    [
                        'field' => 'category_id',
                        'operator' => '=',
                        'value' => $_GET['category'],
                        'type' => 'AND'
                    ],
                    [
                        'field' => 'location_id',
                        'operator' => '=',
                        'value' => $_GET['location'],
                        'type' => 'AND'
                    ],
                    [
                        'field' => 'closing_date',
                        'operator' => '>',
                        'value' => (new \DateTime())->format('Y-m-d H:i:s'),
                        'type' => 'AND'
                    ],
                    [
                        'field' => 'is_archived',
                        'operator' => '=',
                        'value' => 'FALSE'
                    ]
                ]
            );
        } elseif (isset($_GET['category'])) {
            $heading = sprintf(
                '%s Jobs',
                $this->categoriesTable->find('category_id', $_GET['category'])[0]['name']
            );
            $jobs = $this->jobsTable->findComplex(
                [
                    [
                        'field' => 'category_id',
                        'operator' => '=',
                        'value' => $_GET['category'],
                        'type' => 'AND'
                    ],
                    [
                        'field' => 'closing_date',
                        'operator' => '>',
                        'value' => (new \DateTime())->format('Y-m-d H:i:s'),
                        'type' => 'AND'
                    ],
                    [
                        'field' => 'is_archived',
                        'operator' => '=',
                        'value' => 'FALSE'
                    ]
                ]
            );
        } elseif (isset($_GET['location'])) {
            $heading = sprintf(
                'Jobs in %s',
                $this->locationsTable->find('location_id', $_GET['location'])[0]['name']
            );
            $jobs = $this->jobsTable->findComplex(
                [
                    [
                        'field' => 'location_id',
                        'operator' => '=',
                        'value' => $_GET['location'],
                        'type' => 'AND'
                    ],
                    [
                        'field' => 'closing_date',
                        'operator' => '>',
                        'value' => (new \DateTime())->format('Y-m-d H:i:s'),
                        'type' => 'AND'
                    ],
                    [
                        'field' => 'is_archived',
                        'operator' => '=',
                        'value' => 'FALSE'
                    ]
                ]
            );
        } else {
            $heading = 'All Jobs';
            $jobs = $this->jobsTable->findComplex(
                [
                    [
                        'field' => 'closing_date',
                        'operator' => '>',
                        'value' => (new \DateTime())->format('Y-m-d H:i:s'),
                        'type' => 'AND'
                    ],
                    [
                        'field' => 'is_archived',
                        'operator' => '=',
                        'value' => 'FALSE'
                    ]
                ]
            );
        }

        return [
            'template' => '/jobs/index.html.php',
            'title' => 'Jobs',
            'variables' => [
                'categories' => $categories,
                'heading' => $heading,
                'jobs' => $jobs,
                'locations' => $locations
            ]
        ];
    }

    public function readPrivileged()
    {
        $categories = $this->categoriesTable->findAll();

        if (isset($_GET['category'])) {
            $results = $this->jobsTable->find('category_id', $_GET['category']);
            $jobs = [];

            foreach ($results as $job) {
                $jobs[] = [
                    'id' => $job['job_id'],
                    'title' => $job['title'],
                    'description' => $job['description'],
                    'salary' => $job['salary'],
                    'closing_date' => $job['closing_date'],
                    'category_id' => $job['category_id'],
                    'category_name' => $this->categoriesTable->find('category_id', $job['category_id'])[0]['name'],
                    'location_id' => $job['location_id'],
                    'location_name' => $this->locationsTable->find('location_id', $job['location_id'])[0]['name'],
                    'applicant_count' => $this->applicationsTable->totalBy('job_id', $job['job_id'])
                ];
            }
        } else {
            $results = $this->jobsTable->findAll();
            $jobs = [];

            foreach ($results as $job) {
                $jobs[] = [
                    'id' => $job['job_id'],
                    'title' => $job['title'],
                    'description' => $job['description'],
                    'salary' => $job['salary'],
                    'closing_date' => $job['closing_date'],
                    'category_id' => $job['category_id'],
                    'category_name' => $this->categoriesTable->find('category_id', $job['category_id'])[0]['name'],
                    'location_id' => $job['location_id'],
                    'location_name' => $this->locationsTable->find('location_id', $job['location_id'])[0]['name'],
                    'applicant_count' => $this->applicationsTable->totalBy('job_id', $job['job_id'])
                ];
            }
        }

        return [
            'template' => '/admin/jobs/index.html.php',
            'title' => 'Admin - Jobs',
            'variables' => [
                'categories' => $categories,
                'jobs' => $jobs
            ]
        ];
    }

    public function update()
    {
        // Fetch a list of categories
        $categories = $this->categoriesTable->findAll();

        // Fetch a list of locations
        $locations = $this->locationsTable->findAll();

        if (isset($_GET['id'])) {
            $job = $this->jobsTable->find('job_id', $_GET['id'])[0];
            $title = 'Admin - Jobs - Update';
        } else {
            $title = 'Admin - Jobs - Create';
        }

        return [
            'template' => '/admin/jobs/update.html.php',
            'title' => $title,
            'variables' => [
                'categories' => $categories,
                'job' => $job ?? null,
                'locations' => $locations
            ]
        ];
    }

    public function saveUpdate()
    {
        $this->jobsTable->save($_POST['job']);

        header('location: /admin/jobs/');
    }

    public function delete()
    {
        $this->jobsTable->delete('job_id', $_POST['id']);

        header('location: /admin/jobs/');
    }

    public function apply()
    {
        if (isset($_GET['id'])) {
            $job = $this->jobsTable->find('job_id', $_GET['id'])[0];
        }

        return [
            'template' => '/jobs/apply.html.php',
            'title' => 'Jobs - Apply',
            'variables' => [
                'job' => $job ?? null
            ]
        ];
    }

    public function saveApply()
    {
        // This code is derived from an article on Cloudinary Blog
        // written by Prosper Otemuyiwa on 15 Feb 2017
        // https://cloudinary.com/blog/file_upload_with_php
        // Accessed 01 Mar 2020
        $currentDir = getcwd();
        $cvUploadsDir = '/uploads/cvs/';
        if (!file_exists($currentDir . $cvUploadsDir)) {
            mkdir($currentDir . $cvUploadsDir, 0755, true);
        }
        $errors = [];
        $validFileExtensions = ['doc', 'docx', 'pdf', 'rtf'];

        $fileName = $_FILES['cv']['name'];
        $fileParts = explode('.', $fileName);
        $fileExt = strtolower(end($fileParts));
        $fileSize = $_FILES['cv']['size'];
        $fileType = $_FILES['cv']['type'];
        $fileTmpName = $_FILES['cv']['tmp_name'];

        $newFileName = uniqid('cv_') . '.' . $fileExt;

        $uploadPath = $currentDir . $cvUploadsDir . $newFileName;

        if (!in_array($fileExt, $validFileExtensions)) {
            $errors[] = '
                This file extension is not allowed. Please upload a DOC, DOCX, PDF or RTF document.
            ';
        }

        if ($fileSize > 5000000) {
            $errors[] = '
                This file exceeds the upload limit of 5MB. Please upload a smaller file.
            ';
        }

        if (empty($errors)) {
            $isUploadSuccessful = move_uploaded_file($fileTmpName, $uploadPath);

            if ($isUploadSuccessful) {
                $_POST['application']['cv'] = $newFileName;
                $this->applicationsTable->insert($_POST['application']);

                header('location: /jobs');
            }
        }
    }

    public function applications()
    {
        if (isset($_GET['id'])) {
            $applications = $this->applicationsTable->find('job_id', $_GET['id']);
            $job = $this->jobsTable->find('job_id', $_GET['id'])[0];
        }

        return [
            'template' => '/admin/jobs/applications/index.html.php',
            'title' => 'Admin - Jobs - Applications',
            'variables' => [
                'applications' => $applications ?? null,
                'job' => $job ?? null
            ]
        ];
    }
}
