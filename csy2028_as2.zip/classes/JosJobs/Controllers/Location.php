<?php

namespace JosJobs\Controllers;

use CupOfPHP\DatabaseTable;

class Location
{
    private $locationsTable;

    public function __construct(
        DatabaseTable $locationsTable
    ) {
        $this->locationsTable = $locationsTable;
    }

    public function read()
    {
        $locations = $this->locationsTable->findAll();

        return [
            'template' => '/admin/locations/index.html.php',
            'title' => 'Admin - Locations',
            'variables' => [
                'locations' => $locations
            ]
        ];
    }

    public function update()
    {
        if (isset($_GET['id'])) {
            $location = $this->locationsTable->find('location_id', $_GET['id'])[0];
            $title = 'Admin - Locations - Update';
        } else {
            $title = 'Admin - Locations - Create';
        }

        return [
            'template' => '/admin/locations/update.html.php',
            'title' => $title,
            'variables' => [
                'location' => $location ?? null
            ]
        ];
    }

    public function saveUpdate()
    {
        $this->locationsTable->save($_POST['location']);

        header('location: /admin/locations/');
    }

    public function delete()
    {
        $this->locationsTable->delete('location_id', $_POST['id']);

        header('location: /admin/locations/');
    }
}
