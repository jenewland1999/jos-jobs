<?php

namespace JosJobs;

/**
 * EntryPoint class.
 *
 * @package  JosJobs
 * @author   Jordan Newland <github@jenewland.me.uk>
 * @license  All Rights Reserved
 * @link     https://github.com/jenewland1999/
 */
class JosJobsRoutes implements \CupOfPHP\IRoutes
{
    private $pdo;

    public function __construct(\PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function getRoutes()
    {
        $applicationsTable = new \CupOfPHP\DatabaseTable($this->pdo, 'applications', 'application_id');
        $categoriesTable = new \CupOfPHP\DatabaseTable($this->pdo, 'categories', 'category_id');
        $jobsTable = new \CupOfPHP\DatabaseTable($this->pdo, 'jobs', 'job_id');
        $locationsTable = new \CupOfPHP\DatabaseTable($this->pdo, 'locations', 'location_id');
        $usersTable = new \CupOfPHP\DatabaseTable($this->pdo, 'users', 'user_id');

        $categoryController = new \JosJobs\Controllers\Category($categoriesTable);
        $jobController = new \JosJobs\Controllers\Job(
            $applicationsTable,
            $categoriesTable,
            $jobsTable,
            $locationsTable
        );
        $locationController = new \JosJobs\Controllers\Location($locationsTable);
        $rootController = new \JosJobs\Controllers\Root($categoriesTable, $jobsTable);
        $userController = new \JosJobs\Controllers\User($usersTable);

        $routes = [
            '' => [
                'GET' => [
                    'controller' => $rootController,
                    'action' => 'home'
                ]
            ],
            'about' => [
                'GET' => [
                    'controller' => $rootController,
                    'action' => 'about'
                ]
            ],
            'about/faq' => [
                'GET' => [
                    'controller' => $rootController,
                    'action' => 'faq'
                ]
            ],
            'jobs' => [
                'GET' => [
                    'controller' => $jobController,
                    'action' => 'read'
                ]
            ],
            'jobs/apply' => [
                'GET' => [
                    'controller' => $jobController,
                    'action' => 'apply'
                ],
                'POST' => [
                    'controller' => $jobController,
                    'action' => 'saveApply'
                ]
            ],
            'admin/jobs' => [
                'GET' => [
                    'controller' => $jobController,
                    'action' => 'readPrivileged'
                ]
            ],
            'admin/jobs/applications' => [
                'GET' => [
                    'controller' => $jobController,
                    'action' => 'applications'
                ]
            ],
            'admin/jobs/create' => [
                'GET' => [
                    'controller' => $jobController,
                    'action' => 'update'
                ],
                'POST' => [
                    'controller' => $jobController,
                    'action' => 'saveUpdate'
                ]
            ],
            'admin/jobs/update' => [
                'GET' => [
                    'controller' => $jobController,
                    'action' => 'update'
                ],
                'POST' => [
                    'controller' => $jobController,
                    'action' => 'saveUpdate'
                ]
            ],
            'admin/jobs/delete' => [
                'POST' => [
                    'controller' => $jobController,
                    'action' => 'delete'
                ]
            ],
            'admin/categories' => [
                'GET' => [
                    'controller' => $categoryController,
                    'action' => 'read'
                ]
            ],
            'admin/categories/create' => [
                'GET' => [
                    'controller' => $categoryController,
                    'action' => 'update'
                ],
                'POST' => [
                    'controller' => $categoryController,
                    'action' => 'saveUpdate'
                ]
            ],
            'admin/categories/update' => [
                'GET' => [
                    'controller' => $categoryController,
                    'action' => 'update'
                ],
                'POST' => [
                    'controller' => $categoryController,
                    'action' => 'saveUpdate'
                ]
            ],
            'admin/categories/delete' => [
                'POST' => [
                    'controller' => $categoryController,
                    'action' => 'delete'
                ]
            ],
            'admin/locations' => [
                'GET' => [
                    'controller' => $locationController,
                    'action' => 'read'
                ]
            ],
            'admin/locations/create' => [
                'GET' => [
                    'controller' => $locationController,
                    'action' => 'update'
                ],
                'POST' => [
                    'controller' => $locationController,
                    'action' => 'saveUpdate'
                ]
            ],
            'admin/locations/update' => [
                'GET' => [
                    'controller' => $locationController,
                    'action' => 'update'
                ],
                'POST' => [
                    'controller' => $locationController,
                    'action' => 'saveUpdate'
                ]
            ],
            'admin/locations/delete' => [
                'POST' => [
                    'controller' => $locationController,
                    'action' => 'delete'
                ]
            ],
            'admin/users' => [
                'GET' => [
                    'controller' => $userController,
                    'action' => 'read'
                ]
            ],
            'admin/users/create' => [
                'GET' => [
                    'controller' => $userController,
                    'action' => 'update'
                ],
                'POST' => [
                    'controller' => $userController,
                    'action' => 'saveUpdate'
                ]
            ],
            'admin/users/update' => [
                'GET' => [
                    'controller' => $userController,
                    'action' => 'update'
                ],
                'POST' => [
                    'controller' => $userController,
                    'action' => 'saveUpdate'
                ]
            ],
            'admin/users/delete' => [
                'POST' => [
                    'controller' => $userController,
                    'action' => 'delete'
                ]
            ]
        ];

        return $routes;
    }
}
